import * as functions from 'firebase-functions';
const admin = require('firebase-admin');

admin.initializeApp(functions.config().firebase);
let db = admin.firestore();

const csv = require('csv-parser')
const corsOptions = {
    origin: '*',
    optionsSuccessStatus: 200
}
const cors = require('cors')(corsOptions);
const sgMail = require('@sendgrid/mail');

const sendgrid_key = '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';
const gcs = require('@google-cloud/storage')();


sgMail.setApiKey(sendgrid_key);


export const upload = functions.https.onRequest(async (req, res) => {
    console.log('upload triggered');
    
    return cors(req, res, async () => {
        
        let results = [];
        const file = gcs.bucket('mailing-dev-80dc9.appspot.com').file('/upload/excel/file');
        const readStream = file.createReadStream();
        res.setHeader("content-type", "application/excel");
        readStream.pipe(csv(['email', 'name']))
            .on('data', (data) => {
                results.push(data);
            })
            .on('end', () => {
                res.json(results).end();
                console.log(results);               
            });
    });
});

export const uploadfile = functions.https.onRequest(async (req, res) => {
    console.log('upload triggered');
    
    return cors(req, res, async () => {
        
        let results = [];
        const file = gcs.bucket('mailing-dev-80dc9.appspot.com').file('/upload/excel/file');
        const readStream = file.createReadStream();
        res.setHeader("content-type", "application/excel");
        readStream.pipe(csv(['email', 'name']))
            .on('data', (data) => {
                results.push(data);
            })
            .on('end', () => {
                saveEmail(req.body.ref, results).then(() => {
                    res.json({success: true}).end();

                }).catch(err => {
                    res.json({success: false, message: err.message}).end();
                })
                console.log(results);
               
            });
    });
});

const saveEmail = function(ref, csv) {

    return new Promise((resolve, rejected) => {
        db.collection(`emails`).doc(ref).get().then(doc => {
            if (!doc.exists) {
              console.log('No such document!');
              rejected({message: 'No such document!'});
            } else {
              console.log('Document data:', doc.data());
      
              let mergedEmails = new Map<string, any>();
      
              let data = doc.data();

              console.log('data===', doc.data());
              csv.map(i => {
                  mergedEmails.set(i.email, i);
              });
      
              data.list.map(i => {
                  mergedEmails.set(i.email, i);
              });

              let list = Array.from(mergedEmails.values());
              data.list = JSON.parse(JSON.stringify(list));
              console.log('updated after====', data);
              db.collection('emails').doc(ref).set(data).then(() => {
                  resolve();
              });
            }
          })
          .catch(err => {
            console.log('Error getting document', err);
            rejected({message: err.message});
          });
    });
    
}

export const sendemail = functions.https.onRequest(async (req, res) => {
    console.log('send email');
    
    return cors(req, res, async () => {
        
        const msg = {
            to: req.body.email,
            from: req.body.from,
            subject: req.body.subject,
            text: req.body.content,
            html: req.body.content,
        };

        console.log('msg', msg);
        sgMail.send(msg).then((mailres) => {
            
            console.log('mailres.errorcode', mailres[0].statusCode);
            if(mailres[0].statusCode >= 200 && mailres[0].statusCode < 400)
                res.json({status: 'sent', code: mailres[0].statusCode}).end();
            else {
                res.json({status: 'fail', code: mailres[0].statusCode}).end();
            }
        }).catch(error => {
            res.json({status: 'server fail', code: 500}).end();
        });
    });
});
