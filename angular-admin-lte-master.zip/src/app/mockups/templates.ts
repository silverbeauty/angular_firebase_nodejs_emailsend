
export const templates_sample = [{
    name : 'Campain for selling product',
    description: ''
}, {
    name : 'Campain for selling product',
    description: ''
}, {
    name : 'Campain for selling product',
    description: ''
}, {
    name : 'Campain for selling product',
    description: ''
}, {
    name : 'Campain for selling product',
    description: ''
}, {
    name : 'Campain for selling product',
    description: ''
}, {
    name : 'Campain for selling product',
    description: ''
}, {
    name : 'Campain for selling product',
    description: ''
}, {
    name : 'Campain for selling product',
    description: ''
}]