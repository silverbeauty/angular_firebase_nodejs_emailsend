import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SendEmailRoutingModule } from './send-email-routing.module';
import { SendComponent } from './send/send.component';
import { HistoryComponent } from './history/history.component';

@NgModule({
  imports: [
    CommonModule,
    SendEmailRoutingModule
  ],
  declarations: [SendComponent, HistoryComponent]
})
export class SendEmailModule { }
